from chalice import Chalice
from utilities import *

app = Chalice(app_name='detect')

@app.route('/')
def index():
    return {'hello': 'world'}

@app.route('/validate/{ip}')
def validate_ip(ip):
   verify = check_blocks(ip)
   if (verify == True):
       return {'message': "{} is a valid IP address".format(ip), "status":"true","institution":""}
   elif (verify == False):
       return {'message': "{} is an invalid IP address".format(ip), "status":"false"}
